
import { Injectable, signal } from '@angular/core';

export interface HistoryItem {
  id: string;
  date: string; // ISO string
  title: string;
  summary: string;
  fullResult: string;
  thumbnail?: string;
  type: 'text' | 'image' | 'mixed' | 'chat' | 'pdf' | 'search';
  sources?: any[]; // For web search
}

@Injectable({
  providedIn: 'root'
})
export class HistoryService {
  private readonly STORAGE_KEY = 'ia_lectura_pro_history_v2';
  history = signal<HistoryItem[]>([]);

  constructor() {
    this.loadHistory();
  }

  private loadHistory() {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      if (stored) {
        this.history.set(JSON.parse(stored));
      }
    } catch (e) {
      console.error('Error loading history:', e);
    }
  }

  saveAnalysis(item: Omit<HistoryItem, 'id' | 'date'>) {
    const newItem: HistoryItem = {
      ...item,
      id: Date.now().toString(),
      date: new Date().toISOString()
    };

    this.history.update(current => [newItem, ...current]);
    this.persist();
  }

  deleteItem(id: string) {
    this.history.update(current => current.filter(item => item.id !== id));
    this.persist();
  }

  clearHistory() {
    this.history.set([]);
    this.persist();
  }

  private persist() {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.history()));
    } catch (e) {
      console.error('Error saving history:', e);
    }
  }
}
