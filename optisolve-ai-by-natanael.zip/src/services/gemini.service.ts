
import { Injectable } from '@angular/core';
import { GoogleGenAI, GenerateContentResponse, Chat, Part, Content } from '@google/genai';

declare var process: any;

export type AnalysisMode = 'summary' | 'qa' | 'chat' | 'search';

@Injectable({
  providedIn: 'root'
})
export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  // Dedicated Chat Method
  async createChatSession(systemInstruction: string): Promise<Chat> {
    return this.ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7
      }
    });
  }

  // Main Analysis Method (Images, PDF, Text)
  async analyzeContent(
    text: string, 
    files: { base64: string, mimeType: string }[], 
    inputLang: string, 
    outputLang: string, 
    mode: AnalysisMode
  ): Promise<{ text: string, sources?: any[] }> {
    
    const parts: Part[] = [];

    // Add files (Images or PDFs)
    for (const file of files) {
      const cleanBase64 = file.base64.split(',')[1] || file.base64;
      parts.push({
        inlineData: {
          mimeType: file.mimeType,
          data: cleanBase64
        }
      });
    }

    // Add text/prompt
    if (text && text.trim().length > 0) {
      parts.push({
        text: mode === 'qa' ? `PREGUNTA: "${text}"` : `TEXTO/CONTEXTO: "${text}"`
      });
    }

    if (parts.length === 0) {
      throw new Error("Por favor proporciona texto, imágenes o documentos.");
    }

    let specificInstructions = '';
    let tools: any[] = [];

    if (mode === 'summary') {
      specificInstructions = `
      MODO RESUMEN:
      Genera un resumen estructurado del documento o imagen. Identifica puntos clave.
      Si es un PDF extenso, sintetiza la introducción, desarrollo y conclusión.
      `;
    } else if (mode === 'qa') {
      specificInstructions = `
      MODO PREGUNTA (Documentos):
      Busca la respuesta a la pregunta del usuario estrictamente en el contenido proporcionado.
      Cita la página o sección si es posible (en caso de PDF).
      `;
    } else if (mode === 'search') {
      specificInstructions = `
      MODO BÚSQUEDA WEB:
      Investiga el tema solicitado usando Google Search.
      Proporciona información actualizada y relevante.
      `;
      // Enable Google Search Tool
      tools = [{ googleSearch: {} }];
    }

    const systemPrompt = `
      Eres "OptiSolve AI", un asistente experto en análisis de documentos y ayuda escolar.
      Idioma de entrada detectado o preferido: ${inputLang}.
      Idioma de salida: ${outputLang}.
      ${specificInstructions}
      IMPORTANTE:
      - Si usas negritas, usa el formato *texto* (asteriscos simples).
      - Si usas cursivas/comillas, usa "texto" (comillas dobles).
    `;

    try {
      // Build config dynamically
      const config: any = {
        systemInstruction: systemPrompt,
        temperature: 0.4
      };

      if (tools.length > 0) {
        config.tools = tools;
      }

      // We construct the content object manually.
      // Casting to 'any' bypasses the "ContentUnion is required" strict type error 
      // if the Content type definition is slightly mismatched in the specific SDK version.
      const contents = [
        {
          role: 'user',
          parts: parts
        }
      ];

      const response: GenerateContentResponse = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: contents as any, 
        config: config
      });

      const groundingMetadata = response.candidates?.[0]?.groundingMetadata;
      const sources = groundingMetadata?.groundingChunks?.map((chunk: any) => chunk.web).filter((w: any) => w);

      return {
        text: response.text || "No se pudo generar respuesta.",
        sources: sources
      };

    } catch (error) {
      console.error('Error analyzing content:', error);
      throw error;
    }
  }
}
