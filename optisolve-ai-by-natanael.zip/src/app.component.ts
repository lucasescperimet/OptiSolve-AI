
import { Component, signal, computed, inject, ElementRef, ViewChild, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GeminiService, AnalysisMode } from './services/gemini.service';
import { HistoryService, HistoryItem } from './services/history.service';
import { Chat } from '@google/genai';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

type ViewState = 'home' | 'upload' | 'result' | 'camera' | 'chat' | 'settings';

interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.component.html',
  styles: [`
    :host {
      display: block;
      height: 100%;
    }
    .scrollbar-hide::-webkit-scrollbar {
        display: none;
    }
    .scrollbar-hide {
        -ms-overflow-style: none;
        scrollbar-width: none;
    }
    /* Camera flash animation */
    @keyframes flash {
      0% { opacity: 1; }
      100% { opacity: 0; }
    }
    .flash-anim {
      animation: flash 0.3s ease-out forwards;
    }
  `]
})
export class AppComponent implements OnDestroy {
  private geminiService = inject(GeminiService);
  public historyService = inject(HistoryService);
  private sanitizer = inject(DomSanitizer);

  // --- Navigation & UI State ---
  currentView = signal<ViewState>('home');
  analysisMode = signal<AnalysisMode>('summary');
  isLoading = signal<boolean>(false);
  error = signal<string | null>(null);

  // --- Input State ---
  textInput = signal<string>('');
  files = signal<{ url: string; base64: string; mimeType: string; name?: string }[]>([]);
  
  // --- Result State ---
  analysisResult = signal<string | null>(null);
  resultSources = signal<any[] | undefined>(undefined);

  // --- Chat State ---
  chatMessages = signal<ChatMessage[]>([]);
  chatInput = signal<string>('');
  private activeChatSession: Chat | null = null;
  @ViewChild('chatContainer') chatContainer!: ElementRef<HTMLDivElement>;

  // Suggestions for the custom chatbot (Opti)
  chatSuggestions = [
    { label: '🧮 Resolver Problema', text: 'Ayúdame a resolver este problema paso a paso:' },
    { label: '📝 Analizar Texto', text: 'Analiza el siguiente texto y mejora su claridad:' },
    { label: '🧠 Explicar Concepto', text: 'Explícame de forma sencilla el concepto de:' },
    { label: '💡 Generar Ideas', text: 'Dame 5 ideas creativas para:' }
  ];

  // --- Camera State ---
  stream: MediaStream | null = null;
  cameraFacingMode = signal<'environment' | 'user'>('environment');
  showFlash = signal<boolean>(false);

  @ViewChild('videoElement') videoElement!: ElementRef<HTMLVideoElement>;
  @ViewChild('canvasElement') canvasElement!: ElementRef<HTMLCanvasElement>;

  // --- File Inputs ---
  @ViewChild('fileInputLibrary') fileInputLibrary!: ElementRef<HTMLInputElement>;
  @ViewChild('fileInputPDF') fileInputPDF!: ElementRef<HTMLInputElement>;


  // --- Computed Helpers ---
  hasContent = computed(() => {
    // Basic validation depending on view
    const hasText = this.textInput().trim().length > 0;
    const hasFiles = this.files().length > 0;
    
    if (this.analysisMode() === 'search') return hasText;
    return hasText || hasFiles;
  });

  // ==========================================
  // HELPER: TEXT FORMATTER
  // ==========================================
  formatText(text: string | null): SafeHtml {
    if (!text) return '';
    
    // 1. Basic sanitization (escape HTML characters)
    let formatted = text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

    // 2. Handle Markdown Bold (**text**) -> <strong>text</strong>
    // Using semantic tags is safer than classes for innerHTML binding
    formatted = formatted.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

    // 3. Handle Markdown Italic (_text_) -> <em>text</em>
    formatted = formatted.replace(/_([^_]+)_/g, '<em>$1</em>');

    // 4. Handle Lists (lines starting with * )
    formatted = formatted.replace(/^\*\s+(.*)$/gm, '• $1');

    // 5. Convert newlines to <br> for display
    formatted = formatted.replace(/\n/g, '<br>');

    // Bypass security to allow the tags to be rendered
    return this.sanitizer.bypassSecurityTrustHtml(formatted);
  }

  // ==========================================
  // NAVIGATION
  // ==========================================
  goHome() {
    this.stopCamera();
    this.currentView.set('home');
    this.resetForm();
  }

  goSettings() {
    this.currentView.set('settings');
  }

  goUpload(mode: AnalysisMode) {
    this.analysisMode.set(mode);
    this.currentView.set('upload');
  }

  goChat() {
    this.currentView.set('chat');
    this.initializeChat();
  }

  openCustomCamera() {
    this.currentView.set('camera');
    this.startCamera();
  }

  viewHistoryItem(item: HistoryItem) {
    if (item.type === 'chat') {
       // Restore simple chat view (read only for now or new session)
       this.analysisResult.set(item.fullResult); 
       this.currentView.set('result'); // Display as result for simplicity
    } else {
       this.analysisResult.set(item.fullResult);
       this.resultSources.set(item.sources);
       this.currentView.set('result');
    }
  }

  resetForm() {
    this.textInput.set('');
    this.files.set([]);
    this.error.set(null);
    this.analysisResult.set(null);
    this.chatMessages.set([]);
    this.resultSources.set(undefined);
  }

  // ==========================================
  // SETTINGS ACTIONS
  // ==========================================
  clearHistory() {
    if(confirm('¿Estás seguro de que quieres borrar todo el historial?')) {
      this.historyService.clearHistory();
    }
  }

  // ==========================================
  // CUSTOM CAMERA SYSTEM
  // ==========================================
  async startCamera() {
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: this.cameraFacingMode() } 
      });
      setTimeout(() => {
        if (this.videoElement && this.videoElement.nativeElement) {
          this.videoElement.nativeElement.srcObject = this.stream;
          this.videoElement.nativeElement.play();
        }
      }, 100);
    } catch (err) {
      console.error("Camera error:", err);
      this.error.set("No se pudo acceder a la cámara.");
      this.currentView.set('home');
    }
  }

  toggleCamera() {
    this.cameraFacingMode.update(mode => mode === 'environment' ? 'user' : 'environment');
    this.stopCamera();
    this.startCamera();
  }

  capturePhoto() {
    if (this.videoElement && this.canvasElement) {
      // Trigger flash effect
      this.showFlash.set(true);
      setTimeout(() => this.showFlash.set(false), 300);

      const video = this.videoElement.nativeElement;
      const canvas = this.canvasElement.nativeElement;
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      const ctx = canvas.getContext('2d');
      // Mirror if user facing
      if (this.cameraFacingMode() === 'user') {
        ctx?.translate(canvas.width, 0);
        ctx?.scale(-1, 1);
      }
      ctx?.drawImage(video, 0, 0);
      
      const base64 = canvas.toDataURL('image/jpeg', 0.85);
      
      this.files.update(f => [...f, {
        url: base64,
        base64: base64,
        mimeType: 'image/jpeg',
        name: 'Captura de Cámara'
      }]);

      setTimeout(() => {
        this.stopCamera();
        this.goUpload('summary'); 
      }, 400); // Wait for flash
    }
  }

  stopCamera() {
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
  }

  ngOnDestroy() {
    this.stopCamera();
  }

  // ==========================================
  // FILE HANDLING (PDF & IMAGES)
  // ==========================================
  triggerPDF() {
    this.fileInputPDF.nativeElement.click();
  }

  triggerLibrary() {
    this.fileInputLibrary.nativeElement.click();
  }

  onFileSelected(event: Event, type: 'image' | 'pdf') {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.processFiles(input.files, type);
    }
    input.value = '';
  }

  async processFiles(fileList: FileList, type: 'image' | 'pdf') {
    const newFiles = [];
    
    for (let i = 0; i < fileList.length; i++) {
      const file = fileList[i];
      try {
        const { base64, url } = await this.readFile(file);
        // Ensure correct mime for PDF
        const mimeType = type === 'pdf' ? 'application/pdf' : (file.type || 'image/jpeg');
        
        newFiles.push({ 
          url: type === 'pdf' ? 'https://upload.wikimedia.org/wikipedia/commons/8/87/PDF_file_icon.svg' : url, // Placeholder icon for PDF display
          base64, 
          mimeType,
          name: file.name
        });
      } catch (e) {
        console.error("File read error", e);
        this.error.set("Error al leer el archivo.");
      }
    }
    this.files.update(current => [...current, ...newFiles]);
  }

  readFile(file: File): Promise<{ url: string; base64: string }> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        resolve({
          url: e.target.result,
          base64: e.target.result
        });
      };
      reader.onerror = (e) => reject(e);
      reader.readAsDataURL(file);
    });
  }

  removeFile(index: number) {
    this.files.update(f => f.filter((_, i) => i !== index));
  }

  // ==========================================
  // CHAT LOGIC (OptiSolve AI)
  // ==========================================
  async initializeChat() {
    if (!this.activeChatSession) {
      // Initial message
      this.chatMessages.set([
        { 
          role: 'model', 
          text: 'Hola. Soy Opti, tu asistente avanzado de OptiSolve AI. ⚡\n\nEstoy diseñado para optimizar tu trabajo y resolver dudas complejas. ¿En qué te ayudo?' 
        }
      ]);
      
      const systemInstruction = `
        Eres Opti, el asistente de inteligencia artificial de la app "OptiSolve AI".
        
        Tus Instrucciones:
        1. Tu objetivo es ser preciso, eficiente y profesional.
        2. Proporciona soluciones directas a problemas matemáticos, lógicos o de redacción.
        3. Mantén un tono técnico pero accesible (Smart/Professional).
        4. Usa listas para organizar información compleja.
        5. Tu idioma principal es el Español.
      `;

      try {
        this.activeChatSession = await this.geminiService.createChatSession(systemInstruction);
      } catch (err) {
        console.error("Failed to init chat session", err);
      }
    }
    this.scrollToBottom();
  }

  useSuggestion(text: string) {
    if (text.endsWith(':')) {
       this.chatInput.set(text + ' ');
    } else {
       this.chatInput.set(text);
       this.sendMessage();
    }
  }

  async sendMessage() {
    const msg = this.chatInput().trim();
    if (!msg) return;

    this.chatMessages.update(m => [...m, { role: 'user', text: msg }]);
    this.chatInput.set('');
    this.isLoading.set(true);
    this.scrollToBottom();

    if (!this.activeChatSession) {
         const systemInstruction = `Eres Opti, asistente de OptiSolve AI.`;
         this.activeChatSession = await this.geminiService.createChatSession(systemInstruction);
    }

    try {
      const result = await this.activeChatSession.sendMessage(msg);
      const responseText = result.text;

      this.chatMessages.update(m => [...m, { role: 'model', text: responseText }]);
      this.scrollToBottom();

      this.historyService.saveAnalysis({
        title: `Chat Opti: ${msg.substring(0, 15)}...`,
        summary: responseText.substring(0, 50) + '...',
        fullResult: `Usuario: ${msg}\n\nOpti: ${responseText}`,
        type: 'chat'
      });

    } catch (e) {
      console.error(e);
      this.chatMessages.update(m => [...m, { role: 'model', text: 'Error de conexión. Por favor, reintenta.' }]);
      this.scrollToBottom();
    } finally {
      this.isLoading.set(false);
    }
  }

  scrollToBottom() {
    setTimeout(() => {
      if (this.chatContainer && this.chatContainer.nativeElement) {
        this.chatContainer.nativeElement.scrollTop = this.chatContainer.nativeElement.scrollHeight;
      }
    }, 100);
  }

  // ==========================================
  // MAIN ANALYSIS (Summary / QA / Search)
  // ==========================================
  async analyze() {
    if (!this.hasContent() || this.isLoading()) return;

    this.isLoading.set(true);
    this.error.set(null);

    try {
      const { text, sources } = await this.geminiService.analyzeContent(
        this.textInput(),
        this.files(),
        'auto',
        'es', 
        this.analysisMode()
      );

      this.analysisResult.set(text);
      this.resultSources.set(sources);
      
      let title = 'Análisis OptiSolve';
      let type: HistoryItem['type'] = 'text';

      if (this.analysisMode() === 'search') {
        title = `Web: ${this.textInput()}`;
        type = 'search';
      } else if (this.files().some(f => f.mimeType === 'application/pdf')) {
        title = `Doc: ${this.files()[0].name || 'PDF'}`;
        type = 'pdf';
      } else if (this.files().length > 0) {
        title = 'Escaneo de Imagen';
        type = 'image';
      }

      this.historyService.saveAnalysis({
        title,
        summary: text.substring(0, 80) + '...',
        fullResult: text,
        type: type,
        thumbnail: this.files().length > 0 && this.files()[0].mimeType.startsWith('image') ? this.files()[0].base64 : undefined,
        sources
      });

      this.currentView.set('result');
      
    } catch (err) {
      this.error.set("Ocurrió un error en el procesamiento. Intenta nuevamente.");
      console.error(err);
    } finally {
      this.isLoading.set(false);
    }
  }
}
